package com.example.navchenta_welcome

class join_creds (
    val emailid :String,
    val session_id: Int
)