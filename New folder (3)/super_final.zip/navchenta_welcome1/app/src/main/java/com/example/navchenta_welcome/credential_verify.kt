package com.example.navchenta_welcome

class credential_verify (
    val email:String
)
