package com.example.navchenta_welcome

class credential_scores(
    val email : String,
    val score : String,
    val answer : String
)