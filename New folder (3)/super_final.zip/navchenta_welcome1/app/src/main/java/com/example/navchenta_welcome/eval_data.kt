package com.example.navchenta_welcome

data class eval_data(
    val email : String,
    val answer : String
)
