package com.example.navchenta_welcome

class credential_delete (
    val id: String
)


