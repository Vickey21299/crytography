package com.example.navchenta_welcome

class credentials_sign_up(
    val name:String,
    val age: String,
    val phonenumber: String,
    val gender: String,
//    val schoolname: String,
    val schoolphone: String,
    val schoolemail: String,
    val schooladdress: String,
    val emailid: String,
    val state: String,
    val district: String,
    val password: String
)
