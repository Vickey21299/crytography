package com.example.navchenta_welcome.navigation.ui.training

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.navchenta_welcome.R

class training : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_training)
    }
}