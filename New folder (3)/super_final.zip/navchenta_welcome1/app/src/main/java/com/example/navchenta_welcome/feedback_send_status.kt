package com.example.navchenta_welcome

data class feedback_send_status(
    val email : String,
    val status : String
)
